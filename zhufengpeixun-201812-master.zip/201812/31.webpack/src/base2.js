module.exports = function () {
    return 'hello2';
}