//版权所有 珠峰培训
module.exports = 'zfpx';