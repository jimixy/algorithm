console.log('i2', window.$);
module.exports = 'i1';