module.exports = {
    dbUrl: 'mongodb://localhost/jwt2',
    secret: 'zfpx'
}