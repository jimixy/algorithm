import name from './base.js';
import './index.less';
console.log(name);