export default {
    namespace: 'home',
    state: {
        name: 'zfpx'
    }
}