let reg = /user\/([^\/]+)\/([^\/]+)/;
let url = '/user/zfpx/9';
let result = url.match(reg);
console.log(result);
