// counter
export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';

//counter2
export const ADD = 'ADD';
export const MINUS = 'MINUS';